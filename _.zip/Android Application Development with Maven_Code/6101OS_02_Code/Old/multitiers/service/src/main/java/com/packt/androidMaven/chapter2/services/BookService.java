package com.packt.androidMaven.chapter2.services;

import com.packt.mavenDroid.chapter2.entity.Book;

public interface BookService {
    Book createBook(String s, String eBook, String black, int i);
}
