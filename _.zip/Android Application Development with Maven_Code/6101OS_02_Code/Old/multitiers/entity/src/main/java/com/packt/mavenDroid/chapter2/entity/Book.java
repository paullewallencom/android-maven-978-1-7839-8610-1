package com.packt.mavenDroid.chapter2.entity;

/**
 * Created by Invité on 08/04/2014.
 */
public class Book {
}
